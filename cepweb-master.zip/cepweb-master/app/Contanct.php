<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Contanct extends Model
{
    //
}
